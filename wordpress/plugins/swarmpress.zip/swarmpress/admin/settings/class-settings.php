<?php
/**
 * Class derived from :
 * https://www.smashingmagazine.com/2016/04/three-approaches-to-adding-configurable-fields-to-your-plugin/
 * https://github.com/rayman813/smashing-custom-fields/blob/master/smashing-fields-approach-1/smashing-fields.php
 *
 * @package swarmpress
 */

namespace SwarmPress\Settings;

use function SwarmPress\Storage\get_settings_info;

/**
 * Class Kredeum_NFTs_Settings
 *
 * @variable string $slug Settings slug
 */
class Settings {

	/**
	 * Slug
	 *
	 * @var string $slug Settings slug
	 */
	private $slug = SWARM_STORAGE . '_settings';

	/**
	 * Constructor
	 */
	public function __construct() {
		// Hook into the admin menu.
			add_action( 'admin_menu', array( $this, 'menu_create' ) );

		// Add Settings and Fields.
		add_action( 'admin_init', array( $this, 'sections_create' ) );
		add_action( 'admin_init', array( $this, 'fields_create' ) );
	}

	/**
	 * Menu create
	 */
	public function menu_create() {
		$page_title = __( 'SwarmPress', 'swarmpress' );
		$menu_title = __( 'SwarmPress', 'swarmpress' );
		$capability = 'edit_posts';
		$menu_slug  = $this->slug;
		$callback   = array( $this, 'page_content' );

		add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $callback, 'dashicons-format-gallery', 11 );
	}

	/**
	 * Page content
	 */
	public function page_content() {
		echo '<div class="wrap">';
		echo '<h2>' . esc_html( __( 'SwarmPress', 'swarmpress' ) ) . '</h2>';

		echo '<form action="options.php" method="POST">';
		settings_fields( $this->slug );
		do_settings_sections( $this->slug );
		submit_button();
		echo '</form></div>';
	}

	/**
	 * Sections create
	 */
	public function sections_create() {
		add_settings_section( 'first_section', __( 'Settings', 'swarmpress' ), array( $this, 'section_callback' ), $this->slug );
	}

	/**
	 * Sections callback
	 *
	 * @param array $arguments Arguments.
	 */
	public function section_callback( $arguments ) {
		switch ( $arguments['id'] ) {
			case 'first_section':
				echo wp_kses(
					// Get text of settings page.
					get_settings_info(),
					array(
						'p' => array(),
						'a' => array(
							'href'   => array(),
							'target' => array(),
						),
					)
				);
				break;
		}
	}

	/**
	 * Fields Create
	 */
	public function fields_create() {
		$fields = fields( $this->slug );

		foreach ( $fields as $field ) {
			add_settings_field( $field['uid'], $field['label'], array( $this, 'field_callback' ), $this->slug, $field['section'], $field );
			register_setting( $this->slug, $field['uid'] );
		}
	}

	/**
	 * Field callback
	 *
	 * @param array $arguments Arguments.
	 */
	public function field_callback( $arguments ) {
		$value = get_option( $arguments['uid'] );
		if ( ! $value ) {
			$value = $arguments['default'];
		}

		switch ( $arguments['type'] ) {

			case 'kmetamask':
				wp_nonce_field( 'ajax-address', 'knonce' );
				printf( '<div id="kredeum-metamask" txt="true"/>' );
				break;

			case 'kcollections':
				wp_nonce_field( 'ajax-address', 'knonce' );
				printf( '<div id="kredeum-select-collection" txt="true" filter="true" />' );
				break;

			case 'text':
			case 'password':
			case 'number':
				printf( '<input name="%1$s" id="%1$s" type="%2$s" placeholder="%3$s" value="%4$s" size="60"/><br/>', esc_html( $arguments['uid'] ), esc_html( $arguments['type'] ), esc_html( $arguments['placeholder'] ), esc_html( $value ) );
				break;

			case 'textarea':
				esc_html( printf( '<textarea name="%1$s" id="%1$s" placeholder="%2$s" rows="5" cols="60">%3$s</textarea><br/>', esc_html( $arguments['uid'] ), esc_html( $arguments['placeholder'] ), esc_html( $value ) ) );
				break;

			case 'select':
			case 'multiselect':
				if ( ! empty( $arguments['options'] ) && is_array( $arguments['options'] ) ) {
					$attributes     = '';
					$options_markup = '';
					foreach ( $arguments['options'] as $key => $label ) {
						$selected        = is_array( $value ) ? selected( $value[ array_search( $key, $value, true ) ], $key, false ) : '';
						$options_markup .= sprintf( '<option value="%s" %s>%s</option>', $key, $selected, $label );
					}
					if ( 'multiselect' === $arguments['type'] ) {
						$attributes = ' multiple ';
					}
					printf(
						'<select name="%1$s[]" id="%1$s" %2$s>%3$s</select>',
						esc_attr( $arguments['uid'] ),
						esc_attr( $attributes ),
						wp_kses(
							$options_markup,
							array(
								'option' => array(
									'value'    => array(),
									'selected' => array(),
								),
							)
						)
					);
				}
				break;

			case 'radio':
			case 'checkbox':
				if ( ! empty( $arguments['options'] ) && is_array( $arguments['options'] ) ) {
					$options_markup = '';
					$iterator       = 0;
					foreach ( $arguments['options'] as $key => $label ) {
						$iterator++;
						$options_markup .= sprintf( '<label for="%1$s_%6$s"><input id="%1$s_%6$s" name="%1$s[]" type="%2$s" value="%3$s" %4$s /> %5$s</label><br/>', $arguments['uid'], $arguments['type'], $key, checked( $value[ array_search( $key, $value, true ) ], $key, false ), $label, $iterator );
					}
					printf( '<fieldset>%s</fieldset>', esc_html( $options_markup ) );
				}
				break;
		}

		if ( array_key_exists( 'helper', $arguments ) ) {
			printf( '<span class="helper"> %s</span>', esc_html( $arguments['helper'] ) );
		}

		if ( array_key_exists( 'supplimental', $arguments ) ) {
			printf( '<p class="description">%s</p>', esc_html( $$arguments['supplimental'] ) );
		}
	}
}
new Settings();
