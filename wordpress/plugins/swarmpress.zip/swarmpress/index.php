<?php
/**
 * Silence is golden .
 *
 * @package swarmpress
 */

die();
