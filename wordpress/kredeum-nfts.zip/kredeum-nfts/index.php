<?php
/**
 * Silence is golden .
 *
 * @package kredeum/nfts
 */

die();
